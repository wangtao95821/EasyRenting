//
//  RootViewController.h
//  BaiduMapApiDemo
//
//  Copyright 2011 Baidu Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UITableViewController {
	NSArray*	_demoNameArray;
	NSArray*	_viewControllerArray;
    NSArray*	_viewControllerTitleArray;
}

@end
